# American Housing Accountability Project — Website

A clean, professional static website for the renter advocacy group focused on documenting fraud, neglect, and unsafe conditions.

## Important Disclaimer
**We are not lawyers.** This is a group of people who have worked in the housing industry and have seen enough of the fraud, cover-ups, unlicensed work, and neglect. The site is for documentation and pattern tracking only — not legal advice.

## Key Features
- Evidence upload UI (photos, leases, contracts)
- Full report form: Name, Property Address, Property Manager, Issues (checkboxes), Notes
- **Running totals dashboard** — automatically groups complaints by property management company
- **Admin Contacts section** (password-protected for the team):
  - Placeholders for Lawyers, Mold Inspectors, Building Officials, HUD Reps, Code Enforcement
  - One-click generate a full formatted complaint list ready to copy and send
  - Demo password: `accountability`
- Clear non-lawyer disclaimer throughout

## Admin Section
The Admin Contacts area is meant for the group only. Unlock it with the password, then click any "Generate List" button to create a ready-to-send summary of all complaints grouped by property management company. Copy it and email or send it when you're ready.
- Mobile-friendly, matching the navy/red branding

## Files
- `index.html` — Main page with form + dashboard
- `styles.css` — Styling
- `assets/logo.jpg` — Logo

## How to Use
1. Open `index.html` in any browser.
2. Submit reports — they appear grouped under the property management company on the Dashboard.
3. Data is local to the browser (for testing). For real public use, connect the form to a backend (Formspree, Google Sheets, Firebase, etc.).

## Hosting
Upload the entire folder to GitHub Pages, Netlify, Vercel, or any static host.

## Next Steps
- Replace placeholder email
- Connect form to real storage so totals are shared across users
- Add more issue types or filters as needed
